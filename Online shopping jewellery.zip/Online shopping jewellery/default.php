<?php
//echo "<script>location.href='index-1.php';</script>";
header("location:index-1.php");
?>