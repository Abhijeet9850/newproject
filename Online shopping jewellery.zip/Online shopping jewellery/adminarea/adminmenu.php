<table border="0">
	<tr>
		<td>| <a href="default.php">Home</a></td>
		<td>| <a href="viewprod.php">Products</a></td>
		<td>| <a href="viewcategories.php">Categories</a></td>
		<td>| <a href="viewsubcat.php">Sub Categories</a></td>
		<td>| <a href="viewusers.php">Users</a> |</td>
		<td>| <a href="viewpage.php">PAGE</a> |</td>
	</tr>
</table>