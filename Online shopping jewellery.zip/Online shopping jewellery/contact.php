<?php
	echo "<script>window.location.href='contact/a.php';</script>";
?>